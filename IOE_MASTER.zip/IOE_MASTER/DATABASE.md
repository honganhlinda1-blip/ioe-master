# Database Design

## students

```
| Field        | Type      |
| ------------ | --------- |
| id           | uuid      |
| student_code | text      |
| full_name    | text      |
| grade        | integer   |
| class_name   | text      |
| created_at   | timestamp |
```

## questions

```
| Field      | Type |
| ---------- | ---- |
| id         | uuid |
| topic      | text |
| difficulty | text |
| question   | text |
| answer     | text |
| status     | text |
```

Status:

- draft
- review
- approved
- published

## tests

```
| Field           | Type    |
| --------------- | ------- |
| id              | uuid    |
| title           | text    |
| grade           | integer |
| total_questions | integer |
```

## attempts

```
| Field        | Type      |
| ------------ | --------- |
| id           | uuid      |
| student_id   | uuid      |
| test_id      | uuid      |
| score        | float     |
| submitted_at | timestamp |
```

## error_analysis

```
| Field          | Type |
| -------------- | ---- |
| id             | uuid |
| student_id     | uuid |
| weakness       | text |
| recommendation | text |
```

## study_plans

```
| Field      | Type |
| ---------- | ---- |
| id         | uuid |
| student_id | uuid |
| plan       | text |
```
