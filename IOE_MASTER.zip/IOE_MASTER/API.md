# API Endpoints

## Generate Test

POST /generate-test

Request

{
"grade": 10,
"topic": "Vocabulary",
"number": 20
}

Response

{
"questions": []
}

## Submit Test

POST /submit-test

Request

{
"student_id": "HS001",
"answers": []
}

## Analyze Student

GET /analyze/{student_id}

Response

{
"weakness": [],
"recommendation": []
}
