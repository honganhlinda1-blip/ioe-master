# User Flow

## Student Journey

Student
↓
Login
↓
Select Topic
↓
Generate Test
↓
Take Test
↓
Submit
↓
AI Grading
↓
Error Analysis
↓
Study Plan

## Teacher Journey

Teacher
↓
Create Question
↓
Review
↓
Question Bank
↓
Publish

## AI Journey

OpenRouter
↓
Generate Test

OpenRouter
↓
Grade Test

OpenRouter
↓
Analyze Errors

OpenRouter
↓
Study Plan
