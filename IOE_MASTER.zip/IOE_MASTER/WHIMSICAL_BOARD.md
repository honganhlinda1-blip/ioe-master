GIÁO VIÊN
↓
Tạo câu hỏi
↓
Kiểm duyệt
↓
Ngân hàng câu hỏi
↓
Supabase

AI
↓
Sinh đề
↓
Kiểm duyệt AI
↓
Xuất bản đề

HỌC SINH
↓
Đăng nhập
↓
Chọn đề
↓
Làm bài
↓
Nộp bài
↓
AI chấm điểm
↓
Phân tích lỗi
↓
Kế hoạch học tập
↓
Supabase

GIÁO VIÊN
↓
Dashboard
├─ Điểm số
├─ Học sinh yếu
├─ Phân tích lỗi
├─ Theo dõi tiến bộ
└─ Báo cáo
