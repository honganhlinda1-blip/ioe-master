# IOE MASTER

Hệ thống AI hỗ trợ học tập tiếng Anh dành cho học sinh THPT.

## Mục tiêu

- Sinh đề tự động
- Chấm điểm tự động
- Phân tích lỗi sai
- Đề xuất kế hoạch học tập cá nhân
- Dashboard giáo viên

## Công nghệ

- Python
- FastAPI
- Supabase
- OpenRouter
- DeepSeek
- n8n
- Whimsical

## Kiến trúc

Teacher
↓
Question Bank
↓
Supabase
↓
AI Generate Test
↓
Student
↓
Submit
↓
AI Grading
↓
Error Analysis
↓
Study Plan
