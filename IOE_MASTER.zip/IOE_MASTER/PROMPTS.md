# Generate Test

You are an English teacher.

Generate a test for Vietnamese high school students.

Requirements:

- Grade: {{grade}}
- Topic: {{topic}}
- Questions: {{number}}

Return JSON only.

# Grade Test

You are an English examiner.

Compare student's answers with answer key.

Return:

{
"score": 0,
"correct": 0,
"wrong": 0
}

# Analyze Errors

Analyze student mistakes.

Identify:

- vocabulary weakness
- grammar weakness
- reading weakness

Suggest improvements.

# Study Plan

Create a 7-day learning plan based on weaknesses.
